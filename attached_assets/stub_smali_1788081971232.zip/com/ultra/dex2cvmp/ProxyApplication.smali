.class public Lcom/ultra/dex2cvmp/ProxyApplication;
.super Landroid/app/Application;
.source "ProxyApplication.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 31
    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    return-void
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .registers 4
    .param p1, "base"  # Landroid/content/Context;

    .line 35
    invoke-super {p0, p1}, Landroid/app/Application;->attachBaseContext(Landroid/content/Context;)V

    .line 37
    :try_start_3
    new-instance v0, Lcom/ultra/dex2cvmp/utils/DexProtector;

    invoke-direct {v0, p1}, Lcom/ultra/dex2cvmp/utils/DexProtector;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, p1}, Lcom/ultra/dex2cvmp/utils/DexProtector;->install(Landroid/content/Context;)V
    :try_end_b
    .catchall {:try_start_3 .. :try_end_b} :catchall_d

    .line 40
    nop

    .line 41
    return-void

    .line 38
    :catchall_d
    move-exception v0

    .line 39
    .local v0, "e":Ljava/lang/Throwable;
    new-instance v1, Ljava/lang/RuntimeException;

    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v1
.end method

.method public onCreate()V
    .registers 4

    .line 45
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 49
    nop

    .line 50
    invoke-virtual {p0}, Lcom/ultra/dex2cvmp/ProxyApplication;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    .line 51
    invoke-static {}, Lcom/ultra/dex2cvmp/data/Const;->getRealApp()Ljava/lang/String;

    move-result-object v1

    .line 52
    invoke-virtual {p0}, Lcom/ultra/dex2cvmp/ProxyApplication;->getBaseContext()Landroid/content/Context;

    move-result-object v2

    .line 49
    invoke-static {v0, v1, v2}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->nativeSwapApplication(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Context;)Landroid/app/Application;

    move-result-object v0

    .line 53
    .local v0, "realApp":Landroid/app/Application;
    if-eqz v0, :cond_19

    .line 54
    invoke-virtual {v0}, Landroid/app/Application;->onCreate()V

    .line 56
    :cond_19
    return-void
.end method
