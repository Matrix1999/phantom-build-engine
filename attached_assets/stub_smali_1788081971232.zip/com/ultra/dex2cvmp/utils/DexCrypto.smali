.class public Lcom/ultra/dex2cvmp/utils/DexCrypto;
.super Ljava/lang/Object;
.source "DexCrypto.java"


# static fields
.field private static final ASSET_KEY_MASK:[B


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 118
    const/16 v0, 0x10

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    sput-object v0, Lcom/ultra/dex2cvmp/utils/DexCrypto;->ASSET_KEY_MASK:[B

    return-void

    :array_a
    .array-data 1
        0x4dt
        0x7at
        0x1ct
        -0x6dt
        -0x1ct
        0x2bt
        0x68t
        -0xbt
        0x37t
        -0x5at
        0x5ct
        -0x2ft
        -0x72t
        0x42t
        -0x4dt
        0x76t
    .end array-data
.end method

.method public constructor <init>()V
    .registers 1

    .line 42
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static FxIjsF([I)[I
    .registers 8
    .param p0, "iArr"  # [I

    .line 245
    const/16 v0, 0x1b

    new-array v0, v0, [I

    .line 246
    .local v0, "r":[I
    const/4 v1, 0x0

    aget v2, p0, v1

    .line 247
    .local v2, "i":I
    aput v2, v0, v1

    .line 248
    const/4 v1, 0x1

    aget v1, p0, v1

    const/4 v3, 0x2

    aget v3, p0, v3

    const/4 v4, 0x3

    aget v4, p0, v4

    filled-new-array {v1, v3, v4}, [I

    move-result-object v1

    .line 249
    .local v1, "t":[I
    const/4 v3, 0x0

    .local v3, "i2":I
    :goto_17
    const/16 v4, 0x1a

    if-ge v3, v4, :cond_40

    .line 250
    rem-int/lit8 v4, v3, 0x3

    rem-int/lit8 v5, v3, 0x3

    aget v5, v1, v5

    ushr-int/lit8 v5, v5, 0x8

    rem-int/lit8 v6, v3, 0x3

    aget v6, v1, v6

    shl-int/lit8 v6, v6, 0x18

    or-int/2addr v5, v6

    add-int/2addr v5, v2

    xor-int/2addr v5, v3

    aput v5, v1, v4

    .line 251
    shl-int/lit8 v4, v2, 0x3

    ushr-int/lit8 v5, v2, 0x1d

    or-int/2addr v4, v5

    rem-int/lit8 v5, v3, 0x3

    aget v5, v1, v5

    xor-int v2, v4, v5

    .line 252
    add-int/lit8 v4, v3, 0x1

    aput v2, v0, v4

    .line 249
    add-int/lit8 v3, v3, 0x1

    goto :goto_17

    .line 254
    .end local v3  # "i2":I
    :cond_40
    return-object v0
.end method

.method private static closeQuiet(Ljava/io/Closeable;)V
    .registers 2
    .param p0, "c"  # Ljava/io/Closeable;

    .line 300
    if-nez p0, :cond_3

    return-void

    .line 301
    :cond_3
    :try_start_3
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_6} :catch_7

    goto :goto_8

    :catch_7
    move-exception v0

    .line 302
    :goto_8
    return-void
.end method

.method private static varargs d([I[I)Ljava/lang/String;
    .registers 6
    .param p0, "e"  # [I
    .param p1, "k"  # [I

    .line 46
    array-length v0, p0

    new-array v0, v0, [C

    .line 47
    .local v0, "c":[C
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_4
    array-length v2, p0

    if-ge v1, v2, :cond_15

    aget v2, p0, v1

    array-length v3, p1

    rem-int v3, v1, v3

    aget v3, p1, v3

    xor-int/2addr v2, v3

    int-to-char v2, v2

    aput-char v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_4

    .line 48
    .end local v1  # "i":I
    :cond_15
    new-instance v1, Ljava/lang/String;

    invoke-direct {v1, v0}, Ljava/lang/String;-><init>([C)V

    return-object v1
.end method

.method public static decrypt([BLjava/io/InputStream;Ljava/io/OutputStream;)V
    .registers 5
    .param p0, "key"  # [B
    .param p1, "input"  # Ljava/io/InputStream;
    .param p2, "output"  # Ljava/io/OutputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 184
    new-instance v0, Ljava/util/zip/InflaterInputStream;

    invoke-direct {v0, p1}, Ljava/util/zip/InflaterInputStream;-><init>(Ljava/io/InputStream;)V

    .line 185
    .local v0, "is":Ljava/util/zip/InflaterInputStream;
    new-instance v1, Ljava/util/zip/InflaterOutputStream;

    invoke-direct {v1, p2}, Ljava/util/zip/InflaterOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 186
    .local v1, "os":Ljava/util/zip/InflaterOutputStream;
    invoke-static {p0, v0, v1}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->exfr([BLjava/io/InputStream;Ljava/io/OutputStream;)V

    .line 187
    invoke-virtual {v1}, Ljava/util/zip/InflaterOutputStream;->close()V

    .line 188
    invoke-virtual {v0}, Ljava/util/zip/InflaterInputStream;->close()V

    .line 189
    return-void
.end method

.method private static decryptBlob([B[B)[B
    .registers 4
    .param p0, "blob"  # [B
    .param p1, "key"  # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 195
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    array-length v1, p0

    invoke-direct {v0, v1}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    .line 196
    .local v0, "out":Ljava/io/ByteArrayOutputStream;
    new-instance v1, Ljava/io/ByteArrayInputStream;

    invoke-direct {v1, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-static {p1, v1, v0}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->decrypt([BLjava/io/InputStream;Ljava/io/OutputStream;)V

    .line 197
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    return-object v1
.end method

.method private static exfr([BLjava/io/InputStream;Ljava/io/OutputStream;)V
    .registers 14
    .param p0, "key"  # [B
    .param p1, "in"  # Ljava/io/InputStream;
    .param p2, "out"  # Ljava/io/OutputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 213
    if-eqz p0, :cond_7a

    array-length v0, p0

    const/16 v1, 0x10

    if-lt v0, v1, :cond_7a

    .line 215
    const/4 v0, 0x4

    new-array v2, v0, [I

    .line 216
    .local v2, "iArr":[I
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_b
    if-ge v3, v0, :cond_32

    .line 217
    mul-int/lit8 v4, v3, 0x4

    .line 218
    .local v4, "b":I
    aget-byte v5, p0, v4

    and-int/lit16 v5, v5, 0xff

    add-int/lit8 v6, v4, 0x1

    aget-byte v6, p0, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x8

    or-int/2addr v5, v6

    add-int/lit8 v6, v4, 0x2

    aget-byte v6, p0, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/2addr v6, v1

    or-int/2addr v5, v6

    add-int/lit8 v6, v4, 0x3

    aget-byte v6, p0, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x18

    or-int/2addr v5, v6

    aput v5, v2, v3

    .line 216
    .end local v4  # "b":I
    add-int/lit8 v3, v3, 0x1

    goto :goto_b

    .line 223
    .end local v3  # "i":I
    :cond_32
    const/4 v0, 0x0

    aget v1, v2, v0

    const/4 v3, 0x2

    aget v3, v2, v3

    xor-int/2addr v1, v3

    const/4 v3, 0x1

    aget v3, v2, v3

    const/4 v4, 0x3

    aget v4, v2, v4

    xor-int/2addr v3, v4

    filled-new-array {v1, v3}, [I

    move-result-object v1

    .line 224
    .local v1, "iArr2":[I
    invoke-static {v2}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->FxIjsF([I)[I

    move-result-object v2

    .line 226
    const/16 v3, 0x2000

    new-array v3, v3, [B

    .line 227
    .local v3, "buf":[B
    const/4 v4, 0x0

    .line 229
    .local v4, "pos":I
    :goto_4d
    invoke-virtual {p1, v3}, Ljava/io/InputStream;->read([B)I

    move-result v5

    .line 230
    .local v5, "read":I
    if-gez v5, :cond_54

    return-void

    .line 231
    :cond_54
    add-int v6, v4, v5

    .line 232
    .local v6, "end":I
    const/4 v7, 0x0

    .line 233
    .local v7, "i5":I
    :goto_57
    if-ge v4, v6, :cond_76

    .line 234
    rem-int/lit8 v8, v4, 0x8

    .line 235
    .local v8, "i6":I
    if-nez v8, :cond_60

    invoke-static {v2, v1}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->nDnv([I[I)V

    .line 236
    :cond_60
    div-int/lit8 v9, v8, 0x4

    aget v9, v1, v9

    rem-int/lit8 v10, v4, 0x4

    mul-int/lit8 v10, v10, 0x8

    shr-int/2addr v9, v10

    int-to-byte v9, v9

    aget-byte v10, v3, v7

    xor-int/2addr v9, v10

    int-to-byte v9, v9

    aput-byte v9, v3, v7

    .line 237
    add-int/lit8 v4, v4, 0x1

    .line 238
    nop

    .end local v8  # "i6":I
    add-int/lit8 v7, v7, 0x1

    .line 239
    goto :goto_57

    .line 240
    :cond_76
    invoke-virtual {p2, v3, v0, v5}, Ljava/io/OutputStream;->write([BII)V

    .line 241
    .end local v5  # "read":I
    .end local v6  # "end":I
    .end local v7  # "i5":I
    goto :goto_4d

    .line 213
    .end local v1  # "iArr2":[I
    .end local v2  # "iArr":[I
    .end local v3  # "buf":[B
    .end local v4  # "pos":I
    :cond_7a
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "key must be 16 bytes"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static loadPhantomLib(Landroid/content/Context;[B)V
    .registers 12
    .param p0, "ctx"  # Landroid/content/Context;
    .param p1, "masked"  # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 133
    const/16 v0, 0x10

    new-array v1, v0, [B

    .line 134
    .local v1, "key":[B
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_5
    if-ge v2, v0, :cond_14

    aget-byte v3, p1, v2

    sget-object v4, Lcom/ultra/dex2cvmp/utils/DexCrypto;->ASSET_KEY_MASK:[B

    aget-byte v4, v4, v2

    xor-int/2addr v3, v4

    int-to-byte v3, v3

    aput-byte v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_5

    .line 136
    .end local v2  # "i":I
    :cond_14
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Landroid/content/Context;->getCodeCacheDir()Ljava/io/File;

    move-result-object v2

    const-string v3, "libphantom.so"

    invoke-direct {v0, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 140
    .local v0, "soFile":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_28

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 142
    :cond_28
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->pickBlobName()Ljava/lang/String;

    move-result-object v2

    .line 143
    .local v2, "blobName":Ljava/lang/String;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/ultra/dex2cvmp/data/Const;->getLib()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "/"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 145
    .local v3, "assetPath":Ljava/lang/String;
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v4

    .line 146
    .local v4, "bis":Ljava/io/InputStream;
    invoke-static {v4}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->readFully(Ljava/io/InputStream;)[B

    move-result-object v5

    .line 147
    .local v5, "blob":[B
    invoke-static {v4}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->closeQuiet(Ljava/io/Closeable;)V

    .line 149
    invoke-static {v5, v1}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->decryptBlob([B[B)[B

    move-result-object v6

    .line 151
    .local v6, "soBytes":[B
    invoke-virtual {v0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v7

    .line 152
    .local v7, "parent":Ljava/io/File;
    if-eqz v7, :cond_69

    invoke-virtual {v7}, Ljava/io/File;->exists()Z

    move-result v8

    if-nez v8, :cond_69

    invoke-virtual {v7}, Ljava/io/File;->mkdirs()Z

    .line 154
    :cond_69
    new-instance v8, Ljava/io/FileOutputStream;

    invoke-direct {v8, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 156
    .local v8, "fos":Ljava/io/FileOutputStream;
    :try_start_6e
    invoke-virtual {v8, v6}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_71
    .catchall {:try_start_6e .. :try_end_71} :catchall_91

    .line 158
    invoke-static {v8}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->closeQuiet(Ljava/io/Closeable;)V

    .line 159
    nop

    .line 160
    const/4 v9, 0x0

    invoke-virtual {v0, v9, v9}, Ljava/io/File;->setWritable(ZZ)Z

    .line 163
    invoke-static {v1, v9}, Ljava/util/Arrays;->fill([BB)V

    .line 164
    invoke-static {v6, v9}, Ljava/util/Arrays;->fill([BB)V

    .line 170
    :try_start_7f
    const-string v9, "z"

    invoke-static {v9}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    :try_end_84
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_7f .. :try_end_84} :catch_85

    goto :goto_86

    :catch_85
    move-exception v9

    .line 171
    :goto_86
    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Ljava/lang/System;->load(Ljava/lang/String;)V

    .line 177
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 178
    return-void

    .line 158
    :catchall_91
    move-exception v9

    invoke-static {v8}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->closeQuiet(Ljava/io/Closeable;)V

    .line 159
    throw v9
.end method

.method private static nDnv([I[I)V
    .registers 8
    .param p0, "iArr"  # [I
    .param p1, "iArr2"  # [I

    .line 258
    const/4 v0, 0x0

    aget v1, p1, v0

    .local v1, "i":I
    const/4 v2, 0x1

    aget v3, p1, v2

    .line 259
    .local v3, "i2":I
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    aget v5, p0, v0

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 260
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    aget v5, p0, v2

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 261
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x2

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 262
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x3

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 263
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x4

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 264
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x5

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 265
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x6

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 266
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x7

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 267
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x8

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 268
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x9

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 269
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xa

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 270
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xb

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 271
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xc

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 272
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xd

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 273
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xe

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 274
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xf

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 275
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x10

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 276
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x11

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 277
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x12

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 278
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x13

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 279
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x14

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 280
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x15

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 281
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x16

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 282
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x17

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 283
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x18

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 284
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x19

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 285
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x1a

    aget v5, p0, v5

    xor-int v3, v4, v5

    .line 286
    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int/2addr v4, v3

    aput v4, p1, v0

    .line 287
    aput v3, p1, v2

    .line 288
    return-void
.end method

.method public static native nativeLoadShards([B[B[[BLjava/lang/ClassLoader;)Ljava/lang/ClassLoader;
.end method

.method public static native nativeSwapApplication(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Context;)Landroid/app/Application;
.end method

.method private static pickBlobName()Ljava/lang/String;
    .registers 9

    .line 202
    nop

    .line 203
    sget-object v0, Landroid/os/Build;->SUPPORTED_ABIS:[Ljava/lang/String;

    .line 204
    nop

    .line 205
    .local v0, "abis":[Ljava/lang/String;
    array-length v1, v0

    const/4 v2, 0x0

    :goto_6
    if-ge v2, v1, :cond_33

    aget-object v3, v0, v2

    .line 206
    .local v3, "abi":Ljava/lang/String;
    if-eqz v3, :cond_30

    const/16 v4, 0x1c

    const/16 v5, 0x5b

    const/16 v6, 0xe

    const/16 v7, 0x58

    const/4 v8, 0x2

    filled-new-array {v6, v7, v8, v4, v5}, [I

    move-result-object v4

    const/16 v5, 0x6f

    const/16 v6, 0x2a

    filled-new-array {v5, v6}, [I

    move-result-object v5

    invoke-static {v4, v5}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->d([I[I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_30

    invoke-static {}, Lcom/ultra/dex2cvmp/data/Const;->getBlobArm64()Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 205
    .end local v3  # "abi":Ljava/lang/String;
    :cond_30
    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    .line 208
    :cond_33
    invoke-static {}, Lcom/ultra/dex2cvmp/data/Const;->getBlobArm()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method static readFully(Ljava/io/InputStream;)[B
    .registers 5
    .param p0, "is"  # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 293
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 294
    .local v0, "out":Ljava/io/ByteArrayOutputStream;
    const/16 v1, 0x2000

    new-array v1, v1, [B

    .line 295
    .local v1, "buf":[B
    :goto_9
    invoke-virtual {p0, v1}, Ljava/io/InputStream;->read([B)I

    move-result v2

    move v3, v2

    .local v3, "n":I
    if-lez v2, :cond_15

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_9

    .line 296
    :cond_15
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    return-object v2
.end method
