.class public Lcom/ultra/dex2cvmp/utils/DexProtector;
.super Ljava/lang/Object;
.source "DexProtector.java"


# static fields
.field public static mContext:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2
    .param p1, "context"  # Landroid/content/Context;

    .line 79
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 80
    sput-object p1, Lcom/ultra/dex2cvmp/utils/DexProtector;->mContext:Landroid/content/Context;

    .line 81
    return-void
.end method

.method private copyNativeLibDirs(Ljava/lang/ClassLoader;Ljava/lang/ClassLoader;)V
    .registers 15
    .param p1, "src"  # Ljava/lang/ClassLoader;
    .param p2, "dst"  # Ljava/lang/ClassLoader;

    .line 233
    :try_start_0
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strPathList()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    .line 234
    .local v0, "plf":Ljava/lang/reflect/Field;
    invoke-virtual {v0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    .line 236
    .local v1, "srcPl":Ljava/lang/Object;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strPathList()Ljava/lang/String;

    move-result-object v2

    invoke-static {p2, v2}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v2

    .line 237
    .local v2, "plfDst":Ljava/lang/reflect/Field;
    invoke-virtual {v2, p2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    .line 239
    .local v3, "dstPl":Ljava/lang/Object;
    const/4 v4, 0x2

    new-array v5, v4, [Ljava/lang/String;

    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strNativeLibDirs()Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    aput-object v6, v5, v7

    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strNativeLibElems()Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x1

    aput-object v6, v5, v8

    :goto_29
    if-ge v7, v4, :cond_50

    aget-object v6, v5, v7
    :try_end_2d
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_2d} :catch_51

    .line 241
    .local v6, "fieldName":Ljava/lang/String;
    :try_start_2d
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v9

    invoke-virtual {v9, v6}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v9

    .line 242
    .local v9, "f":Ljava/lang/reflect/Field;
    invoke-virtual {v9, v8}, Ljava/lang/reflect/Field;->setAccessible(Z)V

    .line 243
    invoke-virtual {v9, v1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    .line 245
    .local v10, "val":Ljava/lang/Object;
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v11

    invoke-virtual {v11, v6}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v11

    .line 246
    .local v11, "fd":Ljava/lang/reflect/Field;
    invoke-virtual {v11, v8}, Ljava/lang/reflect/Field;->setAccessible(Z)V

    .line 247
    invoke-virtual {v11, v3, v10}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_4a
    .catch Ljava/lang/NoSuchFieldException; {:try_start_2d .. :try_end_4a} :catch_4b
    .catch Ljava/lang/Exception; {:try_start_2d .. :try_end_4a} :catch_51

    .end local v9  # "f":Ljava/lang/reflect/Field;
    .end local v10  # "val":Ljava/lang/Object;
    .end local v11  # "fd":Ljava/lang/reflect/Field;
    goto :goto_4c

    .line 248
    :catch_4b
    move-exception v9

    :goto_4c
    nop

    .line 239
    .end local v6  # "fieldName":Ljava/lang/String;
    add-int/lit8 v7, v7, 0x1

    goto :goto_29

    .line 252
    .end local v0  # "plf":Ljava/lang/reflect/Field;
    .end local v1  # "srcPl":Ljava/lang/Object;
    .end local v2  # "plfDst":Ljava/lang/reflect/Field;
    .end local v3  # "dstPl":Ljava/lang/Object;
    :cond_50
    goto :goto_52

    .line 250
    :catch_51
    move-exception v0

    .line 253
    :goto_52
    return-void
.end method

.method private static varargs d([I[I)Ljava/lang/String;
    .registers 6
    .param p0, "e"  # [I
    .param p1, "k"  # [I

    .line 45
    array-length v0, p0

    new-array v0, v0, [C

    .line 46
    .local v0, "c":[C
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_4
    array-length v2, p0

    if-ge v1, v2, :cond_15

    aget v2, p0, v1

    array-length v3, p1

    rem-int v3, v1, v3

    aget v3, p1, v3

    xor-int/2addr v2, v3

    int-to-char v2, v2

    aput-char v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_4

    .line 47
    .end local v1  # "i":I
    :cond_15
    new-instance v1, Ljava/lang/String;

    invoke-direct {v1, v0}, Ljava/lang/String;-><init>([C)V

    return-object v1
.end method

.method public static getRealAppClass()Ljava/lang/String;
    .registers 1

    .line 270
    invoke-static {}, Lcom/ultra/dex2cvmp/data/Const;->getRealApp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static varargs k([C)Ljava/lang/String;
    .registers 2
    .param p0, "c"  # [C

    .line 43
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, p0}, Ljava/lang/String;-><init>([C)V

    return-object v0
.end method

.method private loadInMemory(Landroid/content/Context;Ljava/io/DataInputStream;I[I[B[B)V
    .registers 12
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "dis"  # Ljava/io/DataInputStream;
    .param p3, "shardCount"  # I
    .param p4, "sizes"  # [I
    .param p5, "salt"  # [B
    .param p6, "pkgNameUtf8"  # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 147
    new-array v0, p3, [[B

    .line 148
    .local v0, "encShards":[[B
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_3
    if-ge v1, p3, :cond_13

    .line 149
    aget v2, p4, v1

    new-array v2, v2, [B

    aput-object v2, v0, v1

    .line 150
    aget-object v2, v0, v1

    invoke-virtual {p2, v2}, Ljava/io/DataInputStream;->readFully([B)V

    .line 148
    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    .line 153
    .end local v1  # "i":I
    :cond_13
    invoke-virtual {p1}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    .line 167
    .local v1, "parent":Ljava/lang/ClassLoader;
    invoke-static {p5, p6, v0, v1}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->nativeLoadShards([B[B[[BLjava/lang/ClassLoader;)Ljava/lang/ClassLoader;

    move-result-object v2

    .line 169
    .local v2, "inMemory":Ljava/lang/ClassLoader;
    if-eqz v2, :cond_24

    .line 173
    invoke-direct {p0, v1, v2}, Lcom/ultra/dex2cvmp/utils/DexProtector;->copyNativeLibDirs(Ljava/lang/ClassLoader;Ljava/lang/ClassLoader;)V

    .line 174
    invoke-direct {p0, p1, v2}, Lcom/ultra/dex2cvmp/utils/DexProtector;->patchLoadedApkClassLoader(Landroid/content/Context;Ljava/lang/ClassLoader;)V

    .line 175
    return-void

    .line 170
    :cond_24
    new-instance v3, Ljava/lang/RuntimeException;

    const/4 v4, 0x7

    new-array v4, v4, [C

    fill-array-data v4, :array_34

    invoke-static {v4}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v3

    :array_34
    .array-data 2
        0x6es
        0x4cs
        0x53s
        0x66s
        0x61s
        0x69s
        0x6cs
    .end array-data
.end method

.method private patchLoadedApkClassLoader(Landroid/content/Context;Ljava/lang/ClassLoader;)V
    .registers 13
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "newCl"  # Ljava/lang/ClassLoader;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 191
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strActThreadCls()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    .line 192
    .local v0, "atCls":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strCurActThread()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    new-array v3, v2, [Ljava/lang/Class;

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    .line 193
    .local v1, "current":Ljava/lang/reflect/Method;
    const/4 v3, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/reflect/Method;->setAccessible(Z)V

    .line 194
    const/4 v4, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    invoke-virtual {v1, v4, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 197
    .local v2, "thread":Ljava/lang/Object;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strMPackages()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v4

    .line 198
    .local v4, "mPackagesField":Ljava/lang/reflect/Field;
    invoke-virtual {v4, v3}, Ljava/lang/reflect/Field;->setAccessible(Z)V

    .line 200
    nop

    .line 201
    invoke-virtual {v4, v2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/util/ArrayMap;

    .line 203
    .local v5, "mPackages":Landroid/util/ArrayMap;, "Landroid/util/ArrayMap<Ljava/lang/String;Ljava/lang/ref/WeakReference<*>;>;"
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/util/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/ref/WeakReference;

    .line 204
    .local v6, "ref":Ljava/lang/ref/WeakReference;, "Ljava/lang/ref/WeakReference<*>;"
    if-eqz v6, :cond_54

    .line 205
    invoke-virtual {v6}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v7

    .line 206
    .local v7, "loadedApk":Ljava/lang/Object;
    if-eqz v7, :cond_54

    .line 207
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v8

    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strMClassLoader()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v8

    .line 208
    .local v8, "mClField":Ljava/lang/reflect/Field;
    invoke-virtual {v8, v3}, Ljava/lang/reflect/Field;->setAccessible(Z)V

    .line 209
    invoke-virtual {v8, v7, p2}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 215
    .end local v7  # "loadedApk":Ljava/lang/Object;
    .end local v8  # "mClField":Ljava/lang/reflect/Field;
    :cond_54
    :try_start_54
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v7

    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strMClassLoader()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v7

    .line 216
    .local v7, "ctxCl":Ljava/lang/reflect/Field;
    invoke-virtual {v7, v3}, Ljava/lang/reflect/Field;->setAccessible(Z)V

    .line 217
    invoke-virtual {v7, p1, p2}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_66
    .catch Ljava/lang/NoSuchFieldException; {:try_start_54 .. :try_end_66} :catch_67

    .end local v7  # "ctxCl":Ljava/lang/reflect/Field;
    goto :goto_68

    .line 218
    :catch_67
    move-exception v3

    :goto_68
    nop

    .line 219
    return-void
.end method

.method private static readAsset(Landroid/content/Context;Ljava/lang/String;)[B
    .registers 4
    .param p0, "ctx"  # Landroid/content/Context;
    .param p1, "path"  # Ljava/lang/String;

    .line 259
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    .line 260
    .local v0, "is":Ljava/io/InputStream;
    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->readFully(Ljava/io/InputStream;)[B

    move-result-object v1

    .line 261
    .local v1, "data":[B
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_f} :catch_10

    .line 262
    return-object v1

    .line 263
    .end local v0  # "is":Ljava/io/InputStream;
    .end local v1  # "data":[B
    :catch_10
    move-exception v0

    .line 264
    .local v0, "e":Ljava/lang/Exception;
    const/4 v1, 0x0

    return-object v1
.end method

.method private static strActThreadCls()Ljava/lang/String;
    .registers 4

    .line 55
    const/16 v0, 0x1a

    new-array v1, v0, [I

    fill-array-data v1, :array_14

    const/16 v2, 0x77

    const/16 v3, 0x34

    filled-new-array {v0, v2, v3}, [I

    move-result-object v0

    invoke-static {v1, v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->d([I[I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_14
    .array-data 4
        0x7b
        0x19
        0x50
        0x68
        0x18
        0x5d
        0x7e
        0x59
        0x55
        0x6a
        0x7
        0x1a
        0x5b
        0x14
        0x40
        0x73
        0x1
        0x5d
        0x6e
        0xe
        0x60
        0x72
        0x5
        0x51
        0x7b
        0x13
    .end array-data
.end method

.method private static strCurActThread()Ljava/lang/String;
    .registers 3

    .line 59
    const/16 v0, 0x15

    new-array v0, v0, [I

    fill-array-data v0, :array_14

    const/16 v1, 0x5e

    const/16 v2, 0x2c

    filled-new-array {v1, v2}, [I

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/utils/DexProtector;->d([I[I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_14
    .array-data 4
        0x3d
        0x59
        0x2c
        0x5e
        0x3b
        0x42
        0x2a
        0x6d
        0x3d
        0x58
        0x37
        0x5a
        0x37
        0x58
        0x27
        0x78
        0x36
        0x5e
        0x3b
        0x4d
        0x3a
    .end array-data
.end method

.method private static strMClassLoader()Ljava/lang/String;
    .registers 3

    .line 67
    const/16 v0, 0xc

    new-array v0, v0, [I

    fill-array-data v0, :array_14

    const/16 v1, 0x52

    const/16 v2, 0x1d

    filled-new-array {v1, v2}, [I

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/utils/DexProtector;->d([I[I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_14
    .array-data 4
        0x3f
        0x5e
        0x3e
        0x7c
        0x21
        0x6e
        0x1e
        0x72
        0x33
        0x79
        0x37
        0x6f
    .end array-data
.end method

.method private static strMPackages()Ljava/lang/String;
    .registers 3

    .line 63
    const/16 v0, 0x9

    new-array v0, v0, [I

    fill-array-data v0, :array_14

    const/16 v1, 0x3f

    const/16 v2, 0x6a

    filled-new-array {v1, v2}, [I

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/utils/DexProtector;->d([I[I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_14
    .array-data 4
        0x52
        0x3a
        0x5e
        0x9
        0x54
        0xb
        0x58
        0xf
        0x4c
    .end array-data
.end method

.method private static strNativeLibDirs()Ljava/lang/String;
    .registers 4

    .line 71
    const/16 v0, 0x18

    new-array v0, v0, [I

    fill-array-data v0, :array_16

    const/16 v1, 0x4b

    const/16 v2, 0x77

    const/16 v3, 0x28

    filled-new-array {v3, v1, v2}, [I

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/utils/DexProtector;->d([I[I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_16
    .array-data 4
        0x46
        0x2a
        0x3
        0x41
        0x3d
        0x12
        0x64
        0x22
        0x15
        0x5a
        0x2a
        0x5
        0x51
        0xf
        0x1e
        0x5a
        0x2e
        0x14
        0x5c
        0x24
        0x5
        0x41
        0x2e
        0x4
    .end array-data
.end method

.method private static strNativeLibElems()Ljava/lang/String;
    .registers 4

    .line 75
    const/16 v0, 0x19

    new-array v0, v0, [I

    fill-array-data v0, :array_16

    const/16 v1, 0x11

    const/16 v2, 0x3c

    const/16 v3, 0x59

    filled-new-array {v2, v3, v1}, [I

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/utils/DexProtector;->d([I[I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_16
    .array-data 4
        0x52
        0x38
        0x65
        0x55
        0x2f
        0x74
        0x70
        0x30
        0x73
        0x4e
        0x38
        0x63
        0x45
        0x9
        0x70
        0x48
        0x31
        0x54
        0x50
        0x3c
        0x7c
        0x59
        0x37
        0x65
        0x4f
    .end array-data
.end method

.method private static strPathList()Ljava/lang/String;
    .registers 3

    .line 51
    const/16 v0, 0x8

    new-array v0, v0, [I

    fill-array-data v0, :array_14

    const/16 v1, 0x3a

    const/16 v2, 0x71

    filled-new-array {v1, v2}, [I

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/utils/DexProtector;->d([I[I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_14
    .array-data 4
        0x4a
        0x10
        0x4e
        0x19
        0x76
        0x18
        0x49
        0x5
    .end array-data
.end method


# virtual methods
.method public install(Landroid/content/Context;)V
    .registers 15
    .param p1, "context"  # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 86
    const/16 v1, 0x10

    new-array v2, v1, [B

    .line 88
    .local v2, "maskedBlobKey":[B
    sget-object v0, Lcom/ultra/dex2cvmp/utils/DexProtector;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/ultra/dex2cvmp/data/Const;->getLib()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "/"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static {}, Lcom/ultra/dex2cvmp/data/Const;->getBundleFile()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    .line 89
    .local v0, "bs":Ljava/io/InputStream;
    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->readFully(Ljava/io/InputStream;)[B

    move-result-object v3

    .line 90
    .local v3, "bundleBytes":[B
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    .line 92
    .end local v0  # "bs":Ljava/io/InputStream;
    array-length v0, v3

    if-lt v0, v1, :cond_11b

    .line 93
    const/4 v5, 0x0

    invoke-static {v3, v5, v2, v5, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 96
    invoke-static {p1, v2}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->loadPhantomLib(Landroid/content/Context;[B)V

    .line 97
    invoke-static {v2, v5}, Ljava/util/Arrays;->fill([BB)V

    .line 101
    :try_start_41
    sget-object v0, Lcom/ultra/dex2cvmp/utils/DexProtector;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/ultra/dex2cvmp/data/Const;->getLib()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-static {}, Lcom/ultra/dex2cvmp/data/Const;->getAppCfg()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    .line 102
    .local v0, "ris":Ljava/io/InputStream;
    const/16 v6, 0x200

    new-array v6, v6, [B

    .line 103
    .local v6, "buf":[B
    invoke-virtual {v0, v6}, Ljava/io/InputStream;->read([B)I

    move-result v7

    .line 104
    .local v7, "n":I
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    .line 105
    if-lez v7, :cond_8b

    .line 106
    new-instance v8, Ljava/lang/String;

    sget-object v9, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v8, v6, v5, v7, v9}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8

    .line 107
    .local v8, "realApp":Ljava/lang/String;
    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_8b

    invoke-static {v8}, Lcom/ultra/dex2cvmp/data/Const;->setRealApp(Ljava/lang/String;)V
    :try_end_89
    .catch Ljava/lang/Exception; {:try_start_41 .. :try_end_89} :catch_8a

    goto :goto_8b

    .line 109
    .end local v0  # "ris":Ljava/io/InputStream;
    .end local v6  # "buf":[B
    .end local v7  # "n":I
    .end local v8  # "realApp":Ljava/lang/String;
    :catch_8a
    move-exception v0

    :cond_8b
    :goto_8b
    nop

    .line 112
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/ultra/dex2cvmp/data/Const;->getLib()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {}, Lcom/ultra/dex2cvmp/data/Const;->getSaltAsset()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->readAsset(Landroid/content/Context;Ljava/lang/String;)[B

    move-result-object v11

    .line 113
    .local v11, "salt":[B
    if-eqz v11, :cond_109

    array-length v0, v11

    if-ne v0, v1, :cond_109

    .line 118
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    sget-object v4, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 119
    invoke-virtual {v0, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v12

    .line 123
    .local v12, "pkgNameUtf8":[B
    :try_start_bc
    new-instance v8, Ljava/io/DataInputStream;

    new-instance v0, Ljava/io/ByteArrayInputStream;

    array-length v4, v3

    sub-int/2addr v4, v1

    invoke-direct {v0, v3, v1, v4}, Ljava/io/ByteArrayInputStream;-><init>([BII)V

    invoke-direct {v8, v0}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    .line 125
    .local v8, "dis":Ljava/io/DataInputStream;
    invoke-virtual {v8}, Ljava/io/DataInputStream;->readInt()I

    move-result v9

    .line 126
    .local v9, "shardCount":I
    new-array v10, v9, [I
    :try_end_ce
    .catchall {:try_start_bc .. :try_end_ce} :catchall_103

    .line 127
    .local v10, "sizes":[I
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_cf
    if-ge v0, v9, :cond_dd

    :try_start_d1
    invoke-virtual {v8}, Ljava/io/DataInputStream;->readInt()I

    move-result v1

    aput v1, v10, v0
    :try_end_d7
    .catchall {:try_start_d1 .. :try_end_d7} :catchall_da

    add-int/lit8 v0, v0, 0x1

    goto :goto_cf

    .line 135
    .end local v0  # "i":I
    .end local v8  # "dis":Ljava/io/DataInputStream;
    .end local v9  # "shardCount":I
    .end local v10  # "sizes":[I
    :catchall_da
    move-exception v0

    move-object v7, p1

    goto :goto_105

    .line 129
    .restart local v8  # "dis":Ljava/io/DataInputStream;
    .restart local v9  # "shardCount":I
    .restart local v10  # "sizes":[I
    :cond_dd
    :try_start_dd
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_df
    .catchall {:try_start_dd .. :try_end_df} :catchall_103

    const/16 v1, 0x1b

    if-lt v0, v1, :cond_ef

    .line 132
    move-object v6, p0

    move-object v7, p1

    .end local p1  # "context":Landroid/content/Context;
    .local v7, "context":Landroid/content/Context;
    :try_start_e5
    invoke-direct/range {v6 .. v12}, Lcom/ultra/dex2cvmp/utils/DexProtector;->loadInMemory(Landroid/content/Context;Ljava/io/DataInputStream;I[I[B[B)V
    :try_end_e8
    .catchall {:try_start_e5 .. :try_end_e8} :catchall_ed

    .line 135
    .end local v8  # "dis":Ljava/io/DataInputStream;
    .end local v9  # "shardCount":I
    .end local v10  # "sizes":[I
    invoke-static {v11, v5}, Ljava/util/Arrays;->fill([BB)V

    .line 136
    nop

    .line 137
    return-void

    .line 135
    :catchall_ed
    move-exception v0

    goto :goto_105

    .line 130
    .end local v7  # "context":Landroid/content/Context;
    .restart local v8  # "dis":Ljava/io/DataInputStream;
    .restart local v9  # "shardCount":I
    .restart local v10  # "sizes":[I
    .restart local p1  # "context":Landroid/content/Context;
    :cond_ef
    move-object v7, p1

    .end local p1  # "context":Landroid/content/Context;
    .restart local v7  # "context":Landroid/content/Context;
    :try_start_f0
    new-instance p1, Ljava/lang/RuntimeException;
    :try_end_f2
    .catchall {:try_start_f0 .. :try_end_f2} :catchall_ed

    const/4 v0, 0x6

    :try_start_f3
    new-array v0, v0, [C

    fill-array-data v0, :array_12c
    :try_end_f8
    .catchall {:try_start_f3 .. :try_end_f8} :catchall_100

    :try_start_f8
    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .end local v2  # "maskedBlobKey":[B
    .end local v3  # "bundleBytes":[B
    .end local v7  # "context":Landroid/content/Context;
    .end local v11  # "salt":[B
    .end local v12  # "pkgNameUtf8":[B
    throw p1
    :try_end_100
    .catchall {:try_start_f8 .. :try_end_100} :catchall_ed

    .line 135
    .end local v8  # "dis":Ljava/io/DataInputStream;
    .end local v9  # "shardCount":I
    .end local v10  # "sizes":[I
    .restart local v2  # "maskedBlobKey":[B
    .restart local v3  # "bundleBytes":[B
    .restart local v7  # "context":Landroid/content/Context;
    .restart local v11  # "salt":[B
    .restart local v12  # "pkgNameUtf8":[B
    :catchall_100
    move-exception v0

    move-object p1, v0

    goto :goto_105

    .end local v7  # "context":Landroid/content/Context;
    .restart local p1  # "context":Landroid/content/Context;
    :catchall_103
    move-exception v0

    move-object v7, p1

    .end local p1  # "context":Landroid/content/Context;
    .restart local v7  # "context":Landroid/content/Context;
    :goto_105
    invoke-static {v11, v5}, Ljava/util/Arrays;->fill([BB)V

    .line 136
    throw v0

    .line 113
    .end local v7  # "context":Landroid/content/Context;
    .end local v12  # "pkgNameUtf8":[B
    .restart local p1  # "context":Landroid/content/Context;
    :cond_109
    move-object v7, p1

    .line 114
    .end local p1  # "context":Landroid/content/Context;
    .restart local v7  # "context":Landroid/content/Context;
    new-instance p1, Ljava/lang/RuntimeException;

    const/16 v0, 0x8

    new-array v0, v0, [C

    fill-array-data v0, :array_136

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 92
    .end local v7  # "context":Landroid/content/Context;
    .end local v11  # "salt":[B
    .restart local p1  # "context":Landroid/content/Context;
    :cond_11b
    move-object v7, p1

    .end local p1  # "context":Landroid/content/Context;
    .restart local v7  # "context":Landroid/content/Context;
    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v0, 0x7

    new-array v0, v0, [C

    fill-array-data v0, :array_142

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1

    :array_12c
    .array-data 2
        0x41s
        0x50s
        0x49s
        0x3cs
        0x32s
        0x37s
    .end array-data

    :array_136
    .array-data 2
        0x62s
        0x61s
        0x64s
        0x20s
        0x73s
        0x61s
        0x6cs
        0x74s
    .end array-data

    :array_142
    .array-data 2
        0x62s
        0x61s
        0x64s
        0x20s
        0x76s
        0x6ds
        0x70s
    .end array-data
.end method
