.class public Lcom/ultra/dex2cvmp/data/Const;
.super Ljava/lang/Object;
.source "Const.java"


# static fields
.field private static REAL_APP:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 52
    const/4 v0, 0x0

    sput-object v0, Lcom/ultra/dex2cvmp/data/Const;->REAL_APP:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static varargs d([I[I)Ljava/lang/String;
    .registers 6
    .param p0, "e"  # [I
    .param p1, "k"  # [I

    .line 13
    array-length v0, p0

    new-array v0, v0, [C

    .line 14
    .local v0, "c":[C
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_4
    array-length v2, p0

    if-ge v1, v2, :cond_15

    aget v2, p0, v1

    array-length v3, p1

    rem-int v3, v1, v3

    aget v3, p1, v3

    xor-int/2addr v2, v3

    int-to-char v2, v2

    aput-char v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_4

    .line 15
    .end local v1  # "i":I
    :cond_15
    new-instance v1, Ljava/lang/String;

    invoke-direct {v1, v0}, Ljava/lang/String;-><init>([C)V

    return-object v1
.end method

.method public static getAppCfg()Ljava/lang/String;
    .registers 3

    .line 30
    const/4 v0, 0x7

    new-array v0, v0, [I

    fill-array-data v0, :array_14

    const/16 v1, 0x44

    const/16 v2, 0x1f

    filled-new-array {v1, v2}, [I

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/data/Const;->d([I[I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_14
    .array-data 4
        0x25
        0x6f
        0x34
        0x31
        0x27
        0x79
        0x23
    .end array-data
.end method

.method public static getBlobArm()Ljava/lang/String;
    .registers 4

    .line 45
    const/16 v0, 0x13

    new-array v0, v0, [I

    fill-array-data v0, :array_16

    const/16 v1, 0x29

    const/16 v2, 0x53

    const/16 v3, 0x61

    filled-new-array {v3, v1, v2}, [I

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/data/Const;->d([I[I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_16
    .array-data 4
        0xd
        0x40
        0x31
        0x11
        0x41
        0x32
        0xf
        0x5d
        0x3c
        0xc
        0x76
        0x32
        0x13
        0x44
        0x7d
        0x3
        0x45
        0x3c
        0x3
    .end array-data
.end method

.method public static getBlobArm64()Ljava/lang/String;
    .registers 4

    .line 40
    const/16 v0, 0x15

    new-array v0, v0, [I

    fill-array-data v0, :array_16

    const/16 v1, 0x13

    const/16 v2, 0x45

    const/16 v3, 0x7a

    filled-new-array {v3, v1, v2}, [I

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/data/Const;->d([I[I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_16
    .array-data 4
        0x16
        0x7a
        0x27
        0xa
        0x7b
        0x24
        0x14
        0x67
        0x2a
        0x17
        0x4c
        0x24
        0x8
        0x7e
        0x73
        0x4e
        0x3d
        0x27
        0x16
        0x7c
        0x27
    .end array-data
.end method

.method public static getBundleFile()Ljava/lang/String;
    .registers 4

    .line 25
    const/16 v0, 0xb

    new-array v0, v0, [I

    fill-array-data v0, :array_16

    const/16 v1, 0x2d

    const/16 v2, 0x11

    const/16 v3, 0x5c

    filled-new-array {v3, v1, v2}, [I

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/data/Const;->d([I[I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_16
    .array-data 4
        0x2c
        0x45
        0x70
        0x32
        0x59
        0x7e
        0x31
        0x3
        0x67
        0x31
        0x5d
    .end array-data
.end method

.method public static getLib()Ljava/lang/String;
    .registers 3

    .line 20
    const/4 v0, 0x7

    new-array v0, v0, [I

    fill-array-data v0, :array_14

    const/16 v1, 0x3a

    const/16 v2, 0x71

    filled-new-array {v1, v2}, [I

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/data/Const;->d([I[I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_14
    .array-data 4
        0x4a
        0x19
        0x5b
        0x1f
        0x4e
        0x1e
        0x57
    .end array-data
.end method

.method public static getRealApp()Ljava/lang/String;
    .registers 4

    .line 55
    sget-object v0, Lcom/ultra/dex2cvmp/data/Const;->REAL_APP:Ljava/lang/String;

    if-nez v0, :cond_1b

    .line 56
    const/16 v0, 0x17

    new-array v0, v0, [I

    fill-array-data v0, :array_1e

    const/16 v1, 0x39

    const/16 v2, 0x7c

    const/16 v3, 0x4d

    filled-new-array {v3, v1, v2}, [I

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/data/Const;->d([I[I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/ultra/dex2cvmp/data/Const;->REAL_APP:Ljava/lang/String;

    .line 57
    :cond_1b
    sget-object v0, Lcom/ultra/dex2cvmp/data/Const;->REAL_APP:Ljava/lang/String;

    return-object v0

    :array_1e
    .array-data 4
        0x2c
        0x57
        0x18
        0x3f
        0x56
        0x15
        0x29
        0x17
        0x1d
        0x3d
        0x49
        0x52
        0xc
        0x49
        0xc
        0x21
        0x50
        0x1f
        0x2c
        0x4d
        0x15
        0x22
        0x57
    .end array-data
.end method

.method public static getSaltAsset()Ljava/lang/String;
    .registers 3

    .line 35
    const/4 v0, 0x7

    new-array v0, v0, [I

    fill-array-data v0, :array_14

    const/16 v1, 0x2b

    const/16 v2, 0x6e

    filled-new-array {v1, v2}, [I

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/data/Const;->d([I[I)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_14
    .array-data 4
        0x5b
        0x6
        0x74
        0x1d
        0x4a
        0x2
        0x5f
    .end array-data
.end method

.method public static setRealApp(Ljava/lang/String;)V
    .registers 2
    .param p0, "name"  # Ljava/lang/String;

    .line 61
    if-eqz p0, :cond_a

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_a

    sput-object p0, Lcom/ultra/dex2cvmp/data/Const;->REAL_APP:Ljava/lang/String;

    .line 62
    :cond_a
    return-void
.end method
